import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity,Button, FlatList, ActivityIndicator, StyleSheet } from 'react-native';
import { Bluetooth } from 'expo';

const App = () => {
  const [devices, setDevices] = useState([]);
  const [scanning, setScanning] = useState(false);

  const startScan = async () => {
    setScanning(true);
    setDevices([]);

    try {
      await Bluetooth.requestAccess();
      await Bluetooth.startScanningAsync();

      Bluetooth.addListener('bluetoothDeviceFound', handleDeviceFound);
    } catch (error) {
      console.error(error);
    }
  };

  const stopScan = async () => {
    setScanning(false);
    Bluetooth.removeListener('bluetoothDeviceFound', handleDeviceFound);
    await Bluetooth.stopScanningAsync();
  };

  const handleDeviceFound = (device) => {
    setDevices((prevDevices) => [...prevDevices, device]);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Bluetooth Connect App</Text>
      <Button
        title={scanning ? 'Stop Scan' : 'Start Scan'}
        onPress={scanning ? stopScan : startScan}
        style={styles.button}
      />
      <View style={styles.devicesContainer}>
        <Text style={styles.devicesText}>Available Devices:</Text>
        {scanning && <ActivityIndicator style={styles.loader} size="small" color="#3498db" />}
      </View>
      <TouchableOpacity
        style={styles.connectButton}
        onPress={scanning ? stopScan : startScan}
        disabled={scanning}
      >
        <Text style={styles.connectButtonText}>{scanning ? 'Connecting...' : 'Connect'}</Text>
      </TouchableOpacity>
      <FlatList
        data={devices}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <Text>{item.name || 'Unnamed Device'}</Text>}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginTop:30,
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  connectButton: {
    marginTop:400,
    backgroundColor: '#3498db',
    width:200,
    height:200,
    alignItems:"center",
    justifyContent:"center",
    // paddingVertical: 50,
    // paddingHorizontal: 50,
    borderRadius: 100,
    marginBottom: 10,
  },
  connectButtonText: {
    color: 'white',
    fontSize: 18,
    textAlign: 'center',
  },
  devicesContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  devicesText: {
    marginRight: 10,
  },
  loader: {
    marginLeft: 5,
  },
});

export default App;

