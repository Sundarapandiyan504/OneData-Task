import { BleManager } from 'react-native-ble-plx';

// const manager = new BleManager();

// function Blu(){
// manager.startDeviceScan(null, null, (error, device) => {
//   if (error) {
//     console.error(error);
//     return;
//   }
//   return device.name
//   console.log('Device found:', device.name || device.id);
// });
// }

// export default Blu